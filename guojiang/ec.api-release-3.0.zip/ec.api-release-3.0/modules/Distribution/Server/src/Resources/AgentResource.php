<?php

namespace GuoJiangClub\Distribution\Server\Resources;

use iBrand\Common\Resources\BaseResource;

class AgentResource extends BaseResource
{
	public function toArray($request)
	{
		return parent::toArray($request);
	}
}