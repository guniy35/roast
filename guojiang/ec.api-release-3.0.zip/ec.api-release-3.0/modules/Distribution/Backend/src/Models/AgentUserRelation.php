<?php

namespace GuoJiangClub\Distribution\Backend\Models;

class AgentUserRelation extends \GuoJiangClub\Distribution\Core\Models\AgentUserRelation
{

}