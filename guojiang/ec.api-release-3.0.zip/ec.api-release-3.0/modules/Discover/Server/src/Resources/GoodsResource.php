<?php

namespace GuoJiangClub\Discover\Server\Resources;

use iBrand\Common\Resources\BaseResource;

class GoodsResource extends BaseResource
{
	public function toArray($request)
	{
		return parent::toArray($request);
	}
}