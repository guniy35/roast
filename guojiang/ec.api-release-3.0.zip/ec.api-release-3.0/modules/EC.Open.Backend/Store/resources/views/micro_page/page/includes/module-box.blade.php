<div class="col-sm-4">

    <span class="btn btn-default col-sm-12 module-box-add" onclick="add('module-box',module_box_slide_html)">幻灯片</span>

</div>

<div class="col-sm-4">

    <span class="btn btn-default col-sm-12 module-box-add" onclick="add('module-box',module_box_coupon_html)">优惠券</span>

</div>

<div class="col-sm-4">

    <span class="btn btn-default col-sm-12 module-box-add" onclick="add('module-box',module_box_nav_html)">快捷导航</span>

</div>

<div class="col-sm-4">

    <span class="btn btn-default col-sm-12 module-box-add" onclick="add('module-box',module_box_cube_html)">魔方</span>

</div>

<div class="col-sm-4">

    <span class="btn btn-default col-sm-12 module-box-add" onclick="add('module-box',module_box_seckill_html)">秒杀</span>

</div>

<div class="col-sm-4">

    <span class="btn btn-default col-sm-12 module-box-add" onclick="add('module-box',module_box_free_event_html)">集call</span>

</div>

<div class="col-sm-4">

    <span class="btn btn-default col-sm-12 module-box-add" onclick="add('module-box',module_box_groupon_html)">拼团</span>

</div>

{{--<div class="col-sm-4">

    <span class="btn btn-default col-sm-12 module-box-add" onclick="add('module-box',module_box_suit_html)">套餐</span>

</div>--}}

<div class="col-sm-4">

    <span class="btn btn-default col-sm-12 module-box-add" onclick="add('module-box',module_box_category_html)">分类商品</span>

</div>

<div class="col-sm-4">

    <span class="btn btn-default col-sm-12 module-box-add" onclick="add('module-box',module_box_goods_group_html)">商品分组</span>

</div>

<div class="col-sm-4">

    <span class="btn btn-default col-sm-12 module-box-add" onclick="add('module-box',module_box_search_html)">搜索框</span>

</div>

<div class="col-sm-4">

    <span class="btn btn-default col-sm-12 module-box-add" onclick="add('module-box',module_box_article_html)">文章</span>

</div>

<div class="col-sm-4">

    <span class="btn btn-default col-sm-12 module-box-add" onclick="add('module-box',module_box_guess_like_html)">猜你喜欢</span>

</div>