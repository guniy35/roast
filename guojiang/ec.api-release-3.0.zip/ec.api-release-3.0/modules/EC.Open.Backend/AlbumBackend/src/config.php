<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2017/3/7
 * Time: 15:25
 */
return [
    'dir' => '{Y}{m}{d}/',
    'size'=>2,
    'num'=>5,
    'mimes' => ['jpg','jpeg', 'png', 'bmp', 'gif'],
];